const express = require('express');
const path = require("path");
const app = express();
const port = 3000, IP = "127.0.0.1";
const filmappe = __dirname;
app.get("/:fil", (req, res, next) => {
  let fil = req.params.fil;
  if (fil.startsWith("opgave")) {
    if (!fil.endsWith(".html")) fil += ".html";
    res.sendFile(path.join(filmappe, fil));
  } else next();
})
app.get("/mult", (req, res) => {
  let x = parseFloat(req.query.x);
  let y = parseFloat(req.query.y);
  res.setHeader('Content-Type', "text/plain");
  res.send((x * y).toString());
});
app.listen(port, IP, () => {
  console.log(`Serveren kører på ${IP}:${port}`);
});